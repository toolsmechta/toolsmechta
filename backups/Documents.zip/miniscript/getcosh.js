//this code was created by me, see. 
//this JS script created to facilitate the process of checking price tags based on a storefront (mechta.kz)
//github: github.com/badcast

//convert bad data string, as number (for coshes)
function evaluate_number(expr) {
	let num = "";
	for (let x = 0; x < expr.length; ++x) {
		if (expr[x] >= '0' && expr[x] <= '9')
			num += (expr[x]);
	}
	return parseInt(num, 10); // convert to number
}

//algo for find coshes and create as Structured data (json) 
function avail() {
	const DISCOUNT_CLASS = "R3C1";
	const COUNT_CLASS = "R3C3";
	
	let models = document.getElementsByClassName("R2C1");
	let coshesH = document.getElementsByClassName("R3");
	let types = document.getElementsByClassName("R1C1");

	//R3C3 - default cosh 
	//R3C1 - discount cosh
	//COSH ELEM document.getElementsByClassName("R3")[0].childNodes[1].className
	let json = []; 

	for (let x = 0; x < coshesH.length; ++x) {
		let yEls = coshesH[x].childNodes;
		for (let y = 0; y < yEls.length; ++y) {
			let zEls = yEls[y];
			let isDiscount;
			let _cosh = -1;
			let type = "not found";
			//filter by element
			if ((isDiscount = (zEls.className == DISCOUNT_CLASS)) || zEls.className == COUNT_CLASS) {
				//text to number format
				_cosh = evaluate_number(zEls.lastChild.innerText);

				json.push({
					//Модель товара
					name: models[json.length].innerText,
					//Цена товара
					cosh: _cosh,
					//Тип - номенклатура
					type: types[json.length].innerText,
					//Скидка
					isDiscount: isDiscount
				});
			}
		}
	}

	return json; // result data 
}

function getDifferents(prevList, newList) {
	let changed = [];
	let addedNew = [];
	let prevRemoved = [];
	for (let x = 0; x < prevList.length; ++x) {
		let changedState = false;
		let newElem = false;
		let founded = false;
		for (let y = 0; newList.length > y; ++y) {
			//forcly equalent string
			let compare = prevList[x].name === newList[y].name && prevList[x].type === newList[y].type;
			if (!changedState && compare) {
				founded=true;
				if (prevList[x].cosh != newList[y].cosh || prevList[x].isDiscount != newList[y].isDiscount) {
					changed.push(newList[y]);
					changedState = true;
					break;
				}
			}
		}

		if(newElem){
			
		}
		else
		if (!founded) {
			prevRemoved.push(prevList[x]); // add as selled
		}
	}
	
	//find newElems
	for(let x = 0; x < newList.length; ++x){
		let newElem = false;
		for(let y = 0; y < prevList.length; ++y){
			let compare = prevList[y].name === newList[x].name && prevList[y].type === newList[x].type;
			if (compare) {
				newElem = true;
				break;
			}
		}
		
		if(!newElem){
			addedNew.push(newList[x]);
		}
	}

	// get differrents 
	return {
		changed: changed,
		addedNew: addedNew,
		prevRemoved: prevRemoved
	};
}

function budget(list) {
	let y = 0;
	for (let x = y; x < list.length; ++x) {
		y += list[x].cosh;
	}
	return y;
}

function print_coshes(json){
	var j = "";
	for(let p = 0; p < json.length; ++p){
		j += json[p].type + " " +(json[p].name + "\n");
	}
	return j;
}

function print_types(alist){
	let types = [];
	alist = alist ?? avail();
	types.push(alist[0].type);
	
	//evaluate a categorized data
	for(let x = types.length; x < alist.length; ++x){
		if(types[types.length-1] != alist[x].type){
			types.push(alist[x].type);
		}
	}
	console.log(types.toString().replaceAll(",",";")) // and replace printer
	return types; // result job
}
