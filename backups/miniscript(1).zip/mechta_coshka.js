//this code was created by me, see. 
//this JS script created to facilitate the process of checking price tags based on a storefront (mechta.kz)
//github: github.com/badcast

//convert bad data string, as number (for coshes)
function evaluate_number(expr) {
	let num = "";
	for (let x = 0; x < expr.length; ++x) {
		if (expr[x] >= '0' && expr[x] <= '9')
			num += (expr[x]);
	}
	return parseInt(num, 10); // convert to number
}

function find_class(coshesH){
	let availed = [null,null];
	
	function _each_complete() {
		return (availed[0] != null && availed[1] != null);
	}
	
	function check_valid_class(validate){
		return ""; // TODO: check validate class (Format: R{N}C{N})
	}
	
	for (let x = 0; !_each_complete() && x < coshesH.length; ++x) {
		let yEls = coshesH[x].childNodes;
		for (let y = 0; !_each_complete() && y < yEls.length; ++y) {
			let zEls = yEls[y];
			let _cosh = 0;
			let className = null;
			
			// description: 
			if(zEls.lastChild == null || zEls.nodeName != 'TD' || zEls.className == null || zEls.lastChild.nodeName != 'SPAN' 
			|| zEls.lastChild.innerText == null 
			|| (_cosh = evaluate_number(zEls.lastChild.innerText)) == 0){
				continue;
			}
						
			className = zEls.className;
			
		
			if(availed[0] == null &&  window.getComputedStyle(zEls).backgroundColor != "rgb(255, 237, 0)"){
				availed[0] = className; //go discount class 
			}
			else if(availed[1] == null)
				availed[1] = className;

		}
	}
	
	return {
		discount_class: availed[0], 
		count_class: availed[1]
	};
}

//algo for find coshes and create as Structured data (json) 
function avail(auto_class = true) {

	let models = document.getElementsByClassName("R2C1");
	let coshesH = document.getElementsByClassName("R3");
	let types = document.getElementsByClassName("R1C1");

	let DISCOUNT_CLASS;
	let COUNT_CLASS;
	if(auto_class){
		let classes = find_class(coshesH); 
		DISCOUNT_CLASS = classes.discount_class;
		COUNT_CLASS = classes.count_class;
	}
	else {
		DISCOUNT_CLASS = "R3C5";
		COUNT_CLASS = "R3C1";
	}
	
	
	console.log("discount class: " + DISCOUNT_CLASS + ", count class: " + COUNT_CLASS);
	

	//COSH ELEM document.getElementsByClassName("R3")[0].childNodes[1].className
	let json = []; 

	for (let x = 0; x < coshesH.length; ++x) {
		let yEls = coshesH[x].childNodes;
		for (let y = 0; y < yEls.length; ++y) {
			let zEls = yEls[y];
			let isDiscount;
			let _cosh = -1;
			let type = "not found";
			//filter by element
			if ((isDiscount = (zEls.className == DISCOUNT_CLASS)) || zEls.className == COUNT_CLASS) {
				//text to number format
				_cosh = evaluate_number(zEls.lastChild.innerText);

				json.push({
					//Модель товара
					name: models[json.length].innerText,
					//Цена товара
					cosh: _cosh,
					//Тип - номенклатура
					type: types[json.length].innerText,
					//Скидка
					isDiscount: isDiscount
				});
			}
		}
	}

	return json; // result data 
}

function difference(prevList, newList) {
	let changed = [];
	let addedNew = [];
	let prevRemoved = [];
	for (let x = 0; x < prevList.length; ++x) {
		let changedState = false;
		let founded = false;
		for (let y = 0; newList.length > y; ++y) {
			//forcly equalent string
			let compare = prevList[x].name === newList[y].name && prevList[x].type === newList[y].type;
			if (!changedState && compare) {
				founded=true;
				if (prevList[x].cosh != newList[y].cosh || prevList[x].isDiscount != newList[y].isDiscount) {
					changed.push(newList[y]);
					changedState = true;
					break;
				}
			}
		}

		if (!founded) {
			prevRemoved.push(prevList[x]); // add as selled
		}
	}
	
	//find newElems
	for(let x = 0; x < newList.length; ++x){
		let newElem = false;
		for(let y = 0; y < prevList.length; ++y){
			let compare = prevList[y].name === newList[x].name && prevList[y].type === newList[x].type;
			if (compare) {
				newElem = true;
				break;
			}
		}
		
		if(!newElem){
			addedNew.push(newList[x]);
		}
	}

	// get differrents 
	return {
		changed: changed,
		addedNew: addedNew,
		prevRemoved: prevRemoved
	};
}

function budget(list) {
	let y = 0;
	for (let x = y; x < list.length; ++x) {
		y += list[x].cosh;
	}
	return y;
}

function print_coshes(json){
	var j = "";
	for(let p = 0; p < json.length; ++p){
		j += json[p].type + " " +(json[p].name + "\n");
	}
	return j;
}

function print_types(alist){
	let types = [];
	alist = alist ?? avail();
	types.push(alist[0].type);
	
	//evaluate a categorized data
	for(let x = types.length; x < alist.length; ++x){
		if(types[types.length-1] != alist[x].type){
			types.push(alist[x].type);
		}
	}
	console.log(types.toString().replaceAll(",",";")) // and replace printer
	return types; // result job
}
